// Created by iWeb 3.0.4 local-build-20170328

setTransparentGifURL('Media/transparent.gif');function hostedOnDM()
{return false;}
function onPageLoad()
{loadMozillaCSS('Blogging_1_Real_files/Blogging_1_RealMoz.css')
adjustLineHeightIfTooBig('id1');adjustFontSizeIfTooBig('id1');fixAllIEPNGs('Media/transparent.gif');performPostEffectsFixups()}
